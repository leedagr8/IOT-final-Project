
<?php
	//This file will define our Database Constants to connect to Master Database

	//echo'j';

	/*Will need to change these parameters to match your database name, root, password, and host*/

	define('DB_NAME','FinalP');
	define('DB_USER', 'root');
	define('DB_PASSWORD', '19656789');
	define('DB_HOST', 'localhost');
?>

