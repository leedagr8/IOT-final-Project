package com.example.lawrencebattle.iot_final_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;;
import android.widget.Switch;
import android.widget.Toast;

public class manage_gen_power_utility extends AppCompatActivity implements View.OnClickListener {

    public Button logout80;
    public Switch gen2,gen3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_gen_power_utility);

        gen2 = (Switch) findViewById(R.id.gen2);
        gen3 = (Switch) findViewById(R.id.gen3);
        logout80 = (Button) findViewById(R.id.logout80);

        logout80.setOnClickListener(manage_gen_power_utility.this);
        gen2.setOnClickListener(manage_gen_power_utility.this);
        gen3.setOnClickListener(manage_gen_power_utility.this);
    }

    @Override
    public void onClick(View v) {
        if(v == logout80){
            Intent intent = new Intent(getApplicationContext(),  MainActivity.class);
            startActivity(intent);        }

        String statusSwitch1, statusSwitch2;
        if (gen2.isChecked())
            statusSwitch1 = gen2.getTextOn().toString();
        else
            statusSwitch1 = gen2.getTextOff().toString();
        if (gen3.isChecked())
            statusSwitch2 = gen3.getTextOn().toString();
        else
            statusSwitch2 = gen3.getTextOff().toString();
        Toast.makeText(getApplicationContext(), "Back Up Generator :" + statusSwitch1 + "\n" + "Main Generator:" + statusSwitch2, Toast.LENGTH_LONG).show();
    }
}
