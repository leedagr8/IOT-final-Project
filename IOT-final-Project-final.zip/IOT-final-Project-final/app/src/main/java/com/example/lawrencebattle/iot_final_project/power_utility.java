package com.example.lawrencebattle.iot_final_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class power_utility extends AppCompatActivity implements View.OnClickListener {


    public Button view_generator, manage_generator, Market, logout_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_power_utility);


        //Declare Buttons
        view_generator = (Button) findViewById(R.id.view_generator);
        manage_generator = (Button) findViewById(R.id.manage_generator);
        Market = (Button) findViewById(R.id.market);
        logout_button = (Button) findViewById(R.id.logout_button);

        //Action Listeners
        view_generator.setOnClickListener(power_utility.this);
        manage_generator.setOnClickListener(power_utility.this);
        Market.setOnClickListener(power_utility.this);
        logout_button.setOnClickListener(power_utility.this);
    }

    @Override
    public void onClick(View v) {

        if(v == logout_button){
            startActivity(new Intent(getApplicationContext(),MainActivity.class));
        }

        if(v == Market){
            startActivity(new Intent(getApplicationContext(),market_power_utility.class));     }

        if(v == manage_generator){
            Intent intent3 = new Intent(getApplicationContext(), manage_gen_power_utility.class);
            startActivity(intent3);        }

        if(v == view_generator){
            startActivity(new Intent(getApplicationContext(),gen_view.class));        }


    }
}
