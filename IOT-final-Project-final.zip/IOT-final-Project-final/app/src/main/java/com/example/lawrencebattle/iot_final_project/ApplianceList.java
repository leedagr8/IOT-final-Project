package com.example.lawrencebattle.iot_final_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;;
import android.widget.Switch;
import android.widget.Toast;

import com.example.lawrencebattle.iot_final_project.MainActivity;
import com.example.lawrencebattle.iot_final_project.R;

public class ApplianceList extends AppCompatActivity implements View.OnClickListener {

    public Button button4;
    public Switch switch2,switch1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appliance_list);

        switch1 = (Switch) findViewById(R.id.switch1);
        switch2 = (Switch) findViewById(R.id.switch2);
        button4 = (Button) findViewById(R.id.button4);

        button4.setOnClickListener(ApplianceList.this);
       switch1.setOnClickListener(ApplianceList.this);
        switch2.setOnClickListener(ApplianceList.this);
    }

    @Override
    public void onClick(View v) {
        if(v == button4){
            Intent intent = new Intent(getApplicationContext(),  MainActivity.class);
            startActivity(intent);        }

        String statusSwitch1, statusSwitch2;
        if (switch1.isChecked())
            statusSwitch1 = switch1.getTextOn().toString();
        else
            statusSwitch1 = switch1.getTextOff().toString();
        if (switch2.isChecked())
            statusSwitch2 = switch2.getTextOn().toString();
        else
            statusSwitch2 = switch2.getTextOff().toString();
        Toast.makeText(getApplicationContext(), "Washer : :" + statusSwitch1 + "\n" + "Dryer:" + statusSwitch2, Toast.LENGTH_LONG).show();
    }
}