package com.example.lawrencebattle.iot_final_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class market_power_utility extends AppCompatActivity implements View.OnClickListener{

    public Button logout100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_market_power_utility);

        logout100 = (Button) findViewById(R.id.logout100);
        logout100.setOnClickListener(market_power_utility.this);
    }

    @Override
    public void onClick(View v) {
        if(v == logout100){
            Intent intent = new Intent(getApplicationContext(),  MainActivity.class);
            startActivity(intent);        }
    }
}
