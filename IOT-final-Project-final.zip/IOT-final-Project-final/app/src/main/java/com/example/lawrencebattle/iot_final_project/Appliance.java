package com.example.lawrencebattle.iot_final_project;


public class Appliance {


}
