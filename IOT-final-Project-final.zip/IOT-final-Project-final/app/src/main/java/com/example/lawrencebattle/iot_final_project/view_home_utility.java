package com.example.lawrencebattle.iot_final_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class view_home_utility extends AppCompatActivity implements View.OnClickListener{

    public Button button6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_home_utility);

        button6 = (Button) findViewById(R.id.button6);


        button6.setOnClickListener(view_home_utility.this);

    }

    @Override
    public void onClick(View v) {

        if(v==button6){
            Intent intent = new Intent(getApplicationContext(),  MainActivity.class);
            startActivity(intent);
        }

    }
}