package com.example.lawrencebattle.iot_final_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

public class view_webcam extends AppCompatActivity implements View.OnClickListener {

    public Button goBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Button
        goBack = (Button) findViewById(R.id.goBack);


        //Sends User to a specific website
        setContentView(R.layout.activity_view_webcam);

        String url = "192.168.1.68/html/";

        WebView gens=(WebView) findViewById(R.id.generator_site);

        gens.loadUrl(url);


        //Action Listeners
       // goBack.setOnClickListener(view_webcam.this);
        goBack.setOnClickListener(view_webcam.this);
    }

    //Not sure if there should be an @Override here
    @Override
    public void onClick(View v) {



        if(v == goBack){
            Intent intent2 = new Intent(getApplicationContext(), view_webcam.class);
            startActivity(intent2);        }

    }
}
