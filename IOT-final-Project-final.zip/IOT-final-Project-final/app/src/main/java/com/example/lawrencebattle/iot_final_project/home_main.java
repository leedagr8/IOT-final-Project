package com.example.lawrencebattle.iot_final_project;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.net.Uri;


public class home_main extends AppCompatActivity implements View.OnClickListener{


    public Button  Logout,Alarm,Appliance,Webcam;
    String url = "http://192.168.1.68/html/";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_main);


        Logout = (Button) findViewById(R.id.Logout);
        Alarm = (Button) findViewById(R.id.Alarm);
        Appliance= (Button) findViewById(R.id.Appliance);
        Webcam = (Button) findViewById(R.id.Webcam);

        Alarm.setOnClickListener(home_main.this);
        Logout.setOnClickListener(home_main.this);
        Appliance.setOnClickListener(home_main.this);
        Webcam.setOnClickListener(home_main.this);

    }

    @Override
    public void onClick(View v) {

        if(v == Logout){
            Intent intent = new Intent(getApplicationContext(),  MainActivity.class);
            startActivity(intent);        }
        if(v == Alarm){
            Intent intent2 = new Intent(getApplicationContext(), alarmSystem.class);
            startActivity(intent2);        }
        if(v == Appliance){
            Intent intent3 = new Intent(getApplicationContext(), ApplianceList.class);
            startActivity(intent3);        }
        if(v == Webcam){
            Intent intent4 = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent4);             }

    }
}
